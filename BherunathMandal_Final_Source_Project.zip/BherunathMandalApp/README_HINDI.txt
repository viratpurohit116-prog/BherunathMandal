BHERUNATH MANDAL — अपडेटेड Android Studio starter project
==========================================================

Screens:
- Home
- Member Registration (name, mobile, village, member photo picker)
- Member List
- Programs
- In-app Notifications
- About Mandal

Buttons:
- Navigation buttons are wired to their respective screens.
- Registration validates fields and saves members on this device.
- When Firebase configuration/services/rules are correct, registration attempts to write member data to Realtime Database and upload selected member photo to Storage.
- General photo/video picker attempts upload to Firebase Storage.

Important limitations:
- This is a source project ZIP, not an installable APK.
- I have not compiled it or run it on a physical Android device, so runtime/build correctness is not confirmed.
- Firebase upload requires Storage enabled and secure rules.
- The member list currently reads locally saved members; it does not yet fetch the full online member list.
- Push notifications require Firebase Cloud Messaging configured and a secure admin/server to send messages.
- Do not use public read/write Firebase rules; member mobile numbers are private information.
