package com.bherunathmandal.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import android.net.Uri;
import android.content.Intent;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.messaging.FirebaseMessaging;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final int saffron = Color.rgb(198, 78, 12);
    private final int deep = Color.rgb(112, 31, 0);
    private final int cream = Color.rgb(255, 247, 230);
    private LinearLayout root, content;
    private final ArrayList<String> members = new ArrayList<>();
    private boolean firebaseReady = false;
    private static final int PICK_MEDIA = 701;
    private static final int PICK_MEMBER_IMAGE = 702;
    private Uri selectedMemberImage = null;
    private TextView memberPhotoStatus = null;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadMembers();
        firebaseReady = FirebaseSetup.initialize(this);
        if (firebaseReady) {
            FirebaseMessaging.getInstance().subscribeToTopic("mandal_updates");
        }
        showHome();
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(12, 10, 12, 10);
        return t;
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(16);
        b.setBackground(bg(saffron, 28));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 7, 0, 7); b.setLayoutParams(p);
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private void startPage(String title) {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(cream);
        TextView header = text("🚩  " + title + "  🚩", 22, Color.WHITE, true);
        header.setBackgroundColor(deep);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(18, 16, 18, 24);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(root);
    }
    private void showHome() {
        startPage("BHERUNATH MANDAL");
        content.addView(text("🙏 जय भैरूजी महाराज 🙏", 26, deep, true));
        content.addView(text("धर्म • सेवा • संस्कृति • एकता", 17, saffron, true));
        TextView note = text("मंडल के कार्यक्रमों और सदस्यों की जानकारी के लिए आपका स्वागत है।", 16, deep, false);
        note.setBackground(bg(Color.WHITE, 20)); content.addView(note);
        content.addView(button("📝  सदस्य रजिस्ट्रेशन", this::showRegistration));
        content.addView(button("👥  सदस्य सूची", this::showMembers));
        content.addView(button("📅  कार्यक्रम", this::showPrograms));
        content.addView(button("🔔  सूचनाएँ", this::showNotifications));
        content.addView(button("📷  फोटो / वीडियो चुनें", this::chooseMedia));
        content.addView(button("ℹ️  मंडल के बारे में", this::showAbout));
        content.addView(text("नोट: सदस्य फोन में सेव होते हैं; ऑनलाइन सेविंग Firebase rules और कनेक्शन पर निर्भर है।", 13, Color.DKGRAY, false));
    }
    private EditText field(String hint, int inputType) {
        EditText e = new EditText(this); e.setHint(hint); e.setTextSize(16);
        e.setSingleLine(true); e.setInputType(inputType);
        e.setPadding(16, 10, 16, 10); e.setBackground(bg(Color.WHITE, 14));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.setMargins(0, 7, 0, 7); e.setLayoutParams(p); return e;
    }
    private void showRegistration() {
        startPage("सदस्य रजिस्ट्रेशन");
        content.addView(text("अपनी जानकारी भरें", 21, deep, true));
        EditText name = field("पूरा नाम",  android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        EditText mobile = field("मोबाइल नंबर", android.text.InputType.TYPE_CLASS_PHONE);
        EditText village = field("गाँव का नाम", android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_WORDS);
        content.addView(name); content.addView(mobile); content.addView(village);
        memberPhotoStatus = text("अभी सदस्य की फोटो नहीं चुनी गई", 14, Color.DKGRAY, false);
        content.addView(memberPhotoStatus);
        content.addView(button("🖼️ सदस्य की फोटो अपलोड करें", () -> {
            Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
            pick.setType("image/*");
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(pick, "सदस्य की फोटो चुनें"), 702);
        }));
        content.addView(button("रजिस्टर करें", () -> {
            String n = name.getText().toString().trim();
            String m = mobile.getText().toString().trim();
            String v = village.getText().toString().trim();
            if (n.isEmpty() || m.isEmpty() || v.isEmpty()) {
                Toast.makeText(this, "कृपया सभी जानकारी भरें।", Toast.LENGTH_SHORT).show(); return;
            }
            if (m.length() < 10) {
                Toast.makeText(this, "मोबाइल नंबर जाँचें।", Toast.LENGTH_SHORT).show(); return;
            }
            members.add(n + "  |  " + m + "  |  " + v);
            saveMembers();
            if (firebaseReady) {
                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("members");
                String key = ref.push().getKey();
                if (key != null) {
                    java.util.HashMap<String, Object> data = new java.util.HashMap<>();
                    data.put("name", n); data.put("mobile", m); data.put("village", v);
                    ref.child(key).setValue(data);
                    if (selectedMemberImage != null) {
                        FirebaseStorage.getInstance().getReference()
                            .child("member_photos/" + key + ".jpg")
                            .putFile(selectedMemberImage)
                            .addOnSuccessListener(task ->
                                Toast.makeText(this, "सदस्य की फोटो अपलोड हो गई।", Toast.LENGTH_LONG).show())
                            .addOnFailureListener(error ->
                                Toast.makeText(this, "फोटो अपलोड नहीं हुई: " + error.getMessage(), Toast.LENGTH_LONG).show());
                    }
                }
            }
            Toast.makeText(this, firebaseReady
                    ? "रजिस्ट्रेशन सेव करने की कोशिश की गई।"
                    : "रजिस्ट्रेशन फोन में सेव हुआ। ऑनलाइन सेवा सेटअप बाकी है।",
                    Toast.LENGTH_LONG).show();
            showMembers();
        }));
        content.addView(button("⬅ वापस होम", this::showHome));
    }
    private void showMembers() {
        startPage("सदस्य सूची");
        content.addView(text("रजिस्टर्ड सदस्य (इस सत्र में)", 20, deep, true));
        if (members.isEmpty()) {
            content.addView(text("अभी कोई सदस्य नहीं। रजिस्ट्रेशन से सदस्य जोड़ें।", 16, Color.DKGRAY, false));
        } else {
            for (int i=0; i<members.size(); i++) {
                TextView t = text((i+1) + ". " + members.get(i), 15, deep, false);
                t.setBackground(bg(Color.WHITE, 14));
                LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
                p.setMargins(0, 5, 0, 5); content.addView(t, p);
            }
        }
        content.addView(button("➕ नया सदस्य जोड़ें", this::showRegistration));
        content.addView(button("⬅ वापस होम", this::showHome));
    }
    private void showPrograms() {
        startPage("कार्यक्रम");
        content.addView(text("🚩 मंडल के कार्यक्रम 🚩", 22, deep, true));
        String[] items = {
            "🙏 भैरूजी महाराज की पूजा एवं भजन",
            "🌺 रविवार को भैरूजी का श्रृंगार",
            "🎶 अलग-अलग स्थानों पर भजन",
            "🧹 मंदिर एवं धार्मिक स्थलों की सफाई",
            "🤝 जरूरतमंद लोगों की सहायता",
            "📸 कार्यक्रमों के फोटो और वीडियो"
        };
        for (String item : items) {
            TextView t = text(item, 17, deep, true); t.setBackground(bg(Color.WHITE, 16));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.setMargins(0, 5, 0, 5); content.addView(t, p);
        }
        content.addView(text("कार्यक्रम का सही समय मंडल के व्यवस्थापक से पुष्टि करें।", 14, Color.DKGRAY, false));
        content.addView(button("⬅ वापस होम", this::showHome));
    }
    private void loadMembers() {
        SharedPreferences prefs = getSharedPreferences("bherunath_mandal", MODE_PRIVATE);
        String raw = prefs.getString("members", "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) members.add(arr.getString(i));
        } catch (Exception ignored) { }
    }

    private void saveMembers() {
        JSONArray arr = new JSONArray();
        for (String member : members) arr.put(member);
        getSharedPreferences("bherunath_mandal", MODE_PRIVATE)
            .edit().putString("members", arr.toString()).apply();
    }

    private void showNotifications() {
        startPage("सूचनाएँ");
        content.addView(text("🔔 मंडल की सूचनाएँ", 22, deep, true));
        String[] notices = {
            "🚩 जय भैरूजी महाराज!",
            "🙏 रविवार को भैरूजी महाराज के श्रृंगार में सभी सदस्य शामिल हों।",
            "🎶 भजन एवं धार्मिक कार्यक्रमों का समय मंडल के व्यवस्थापक से पुष्टि करें।",
            "🤝 मंडल की गतिविधियों और सेवा कार्यों में सहयोग करें।"
        };
        for (String notice : notices) {
            TextView t = text(notice, 16, deep, false);
            t.setBackground(bg(Color.WHITE, 16));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
            p.setMargins(0, 5, 0, 5); content.addView(t, p);
        }
        content.addView(text("यह अभी ऐप के अंदर दिखाई देने वाली सूचनाएँ हैं। फोन पर push notification भेजने के लिए Firebase Cloud Messaging और सर्वर सेटअप बाकी है।", 13, Color.DKGRAY, false));
        content.addView(button("⬅ वापस होम", this::showHome));
    }

    private void chooseMedia() {
        Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
        pick.setType("*/*");
        pick.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "video/*"});
        pick.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(Intent.createChooser(pick, "फोटो या वीडियो चुनें"), PICK_MEDIA);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == PICK_MEMBER_IMAGE) {
            selectedMemberImage = uri;
            if (memberPhotoStatus != null) memberPhotoStatus.setText("✅ सदस्य की फोटो चुनी गई");
            if (!firebaseReady) {
                Toast.makeText(this, "फोटो चुनी गई है। ऑनलाइन अपलोड के लिए Firebase सेटअप जरूरी है।", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "फोटो चुनी गई। रजिस्ट्रेशन करते समय अपलोड होगी।", Toast.LENGTH_LONG).show();
            }
            return;
        }

        if (requestCode != PICK_MEDIA) return;
        if (!firebaseReady) {
            Toast.makeText(this, "मीडिया चुना गया। ऑनलाइन अपलोड के लिए Firebase सेटअप बाकी है।", Toast.LENGTH_LONG).show();
            return;
        }
        String fileName = "mandal_media/" + System.currentTimeMillis();
        StorageReference ref = FirebaseStorage.getInstance().getReference().child(fileName);
        ref.putFile(uri).addOnSuccessListener(task ->
                Toast.makeText(this, "मीडिया अपलोड हो गया।", Toast.LENGTH_LONG).show()
        ).addOnFailureListener(error ->
                Toast.makeText(this, "अपलोड नहीं हुआ: " + error.getMessage(), Toast.LENGTH_LONG).show()
        );
    }

    private void showAbout() {
        startPage("मंडल के बारे में");
        content.addView(text("BHERUNATH MANDAL", 24, deep, true));
        content.addView(text("हमारा उद्देश्य भैरूजी महाराज की भक्ति, सामाजिक सेवा, सांस्कृतिक गतिविधियों और आपसी सहयोग को बढ़ावा देना है।", 17, deep, false));
        content.addView(text("🚩 जय भैरूजी महाराज 🚩", 21, saffron, true));
        content.addView(button("⬅ वापस होम", this::showHome));
    }
}