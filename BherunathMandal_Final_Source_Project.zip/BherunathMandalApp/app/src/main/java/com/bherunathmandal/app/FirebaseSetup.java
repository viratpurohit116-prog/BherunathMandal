package com.bherunathmandal.app;

import android.content.Context;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;

/**
 * Firebase client configuration for the selected Android app.
 * Database and Storage rules still must be configured securely in Firebase Console.
 */
public final class FirebaseSetup {
    private FirebaseSetup() {}

    public static boolean initialize(Context context) {
        if (!FirebaseApp.getApps(context).isEmpty()) return true;

        String apiKey = "AIzaSyAZiIYgHG48bEe6ttdzwWCEEyTsbPwHCHE";
        String appId = "1:598643051965:android:0ad1a8a91edd74437f16d4";
        String projectId = "bherunath-mandal";
        String databaseUrl = "https://bherunath-mandal-default-rtdb.firebaseio.com";
        String bucket = "bherunath-mandal.firebasestorage.app";


        FirebaseOptions options = new FirebaseOptions.Builder()
                .setApiKey(apiKey)
                .setApplicationId(appId)
                .setProjectId(projectId)
                .setDatabaseUrl(databaseUrl)
                .setStorageBucket(bucket)
                .build();
        FirebaseApp.initializeApp(context, options);
        return true;
    }
}
